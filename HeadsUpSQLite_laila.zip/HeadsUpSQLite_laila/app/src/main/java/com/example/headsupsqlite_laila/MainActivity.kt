package com.example.headsupsqlite_laila

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    lateinit var Recycler_View: RecyclerView

    lateinit var EditText_add_Name : EditText
    lateinit var EditText_add_Taboo1 : EditText
    lateinit var EditText_add_Taboo2 : EditText
    lateinit var EditText_add_Taboo3 : EditText

    lateinit var Button_Save : Button

    var Celebrity_List = arrayListOf<Celebrity>()

    var Name =""
    var taboo1 =""
    var taboo2 =""
    var taboo3 =""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        EditText_add_Name = findViewById(R.id.EditText_add_Name)
        EditText_add_Taboo1 = findViewById(R.id.EditText_add_Taboo1)
        EditText_add_Taboo2 = findViewById(R.id.EditText_add_Taboo2)
        EditText_add_Taboo3 = findViewById(R.id.EditText_add_Taboo3)

        Button_Save = findViewById(R.id.Button_Save)

        Recycler_View = findViewById(R.id.Recycler_View)
        Recycler_View.adapter = Adapter(Celebrity_List)
        Recycler_View.layoutManager = LinearLayoutManager(this)
        Recycler_View.adapter!!.notifyDataSetChanged()

        Button_Save.setOnClickListener {
            Name = EditText_add_Name.text.toString()
            taboo1 = EditText_add_Taboo1.text.toString()
            taboo2 = EditText_add_Taboo2.text.toString()
            taboo3 = EditText_add_Taboo3.text.toString()

            if(Name.isNotEmpty() && taboo1.isNotEmpty() && taboo2.isNotEmpty() && taboo3.isNotEmpty()) {
                var helper = DBHelper(applicationContext)
                var add = helper.add(Name, taboo1, taboo2, taboo3)

                Celebrity_List.add(Celebrity(Name, taboo1, taboo2, taboo3))
                Recycler_View.adapter!!.notifyDataSetChanged()

                EditText_add_Name.text.clear()
                EditText_add_Taboo1.text.clear()
                EditText_add_Taboo2.text.clear()
                EditText_add_Taboo3.text.clear()
                Toast.makeText(this, "New Celebrity is Added $add".uppercase(), Toast.LENGTH_LONG)
                    .show()
            }
            else{

                Toast.makeText(this, "Please Enter a Information Correctly!!", Toast.LENGTH_LONG)
                    .show()

            }
        }
    }
}