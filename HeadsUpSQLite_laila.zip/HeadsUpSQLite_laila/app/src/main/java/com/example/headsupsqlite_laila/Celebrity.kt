package com.example.headsupsqlite_laila

data class Celebrity (val name: String, val taboo1: String, val taboo2: String, val taboo3: String)