package com.example.headsupsqlite_laila

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context): SQLiteOpenHelper(context, "celebrity_details.db", null, 1){

    private var sqLiteDatabase: SQLiteDatabase = writableDatabase

    override fun onCreate(db: SQLiteDatabase?) {
        if(db != null)
        {
            db?.execSQL("CREATE TABLE CelebrityTable(Name TEXT, taboo1 TEXT, taboo2 TEXT, taboo3 TEXT)")
        }
    }

    override fun onUpgrade(db: SQLiteDatabase?, p1: Int, p2: Int) {
    }

    fun add(Name: String, taboo1: String, taboo2: String, taboo3: String): Long{

        val contentValues = ContentValues()
        contentValues.put("Name", Name)
        contentValues.put("taboo1", taboo1)
        contentValues.put("taboo2", taboo2)
        contentValues.put("taboo3", taboo3)

        return sqLiteDatabase.insert("CelebrityTable", null, contentValues)
    }
}