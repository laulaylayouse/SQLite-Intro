package com.example.notesapp_laila

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper (context: Context) : SQLiteOpenHelper(context, "notes_details.db", null, 1) {

    private var sqLiteDatabase: SQLiteDatabase = writableDatabase

    override fun onCreate(db: SQLiteDatabase?) {
        if(db != null)
        {
            db?.execSQL("create table notes (Message text )")
        }
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("Not yet implemented")
    }

    fun savedata(s1: String): Long {

        val Content_Values = ContentValues()
        Content_Values.put("Message", s1)

        return sqLiteDatabase.insert("notes", null, Content_Values)
    }
}