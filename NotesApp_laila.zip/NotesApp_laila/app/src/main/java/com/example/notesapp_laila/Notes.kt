package com.example.notesapp_laila

data class Notes(val noteText: String)